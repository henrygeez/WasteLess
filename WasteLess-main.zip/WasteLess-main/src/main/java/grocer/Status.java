package grocer;

public enum Status {

    IN_PROGRESS,
    COMPLETED,
    CANCELLED,
    ACCEPTED,
    PENDING
}